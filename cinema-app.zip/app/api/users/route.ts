import { NextResponse } from "next/server"
import type { User } from "@/lib/api-services"

// Sample users data (in a real app, this would be in a database)
const users: User[] = [
  {
    id: 1,
    name: "John Doe",
    email: "john.doe@example.com",
    role: "client",
    registeredDate: "2025-01-15",
    status: "active",
  },
  {
    id: 2,
    name: "Jane Smith",
    email: "jane.smith@example.com",
    role: "client",
    registeredDate: "2025-02-20",
    status: "active",
  },
  {
    id: 3,
    name: "Robert Johnson",
    email: "robert.j@example.com",
    role: "client",
    registeredDate: "2025-03-05",
    status: "inactive",
  },
  {
    id: 4,
    name: "Emily Davis",
    email: "emily.d@example.com",
    role: "client",
    registeredDate: "2025-03-10",
    status: "active",
  },
  {
    id: 5,
    name: "Michael Wilson",
    email: "michael.w@example.com",
    role: "admin",
    registeredDate: "2025-03-15",
    status: "active",
  },
]

export async function GET() {
  return NextResponse.json(users)
}

export async function POST(request: Request) {
  const newUser = await request.json()

  // Generate a new ID (in a real app, the database would handle this)
  const maxId = users.reduce((max, user) => (user.id > max ? user.id : max), 0)
  const userWithId = { ...newUser, id: maxId + 1 }

  // Add to our "database"
  users.push(userWithId)

  return NextResponse.json(userWithId, { status: 201 })
}
