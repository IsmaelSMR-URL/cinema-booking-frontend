import { NextResponse } from "next/server"
import type { User } from "@/lib/api-services"

// Sample users data (in a real app, this would be in a database)
let users: User[] = [
  {
    id: 1,
    name: "John Doe",
    email: "john.doe@example.com",
    role: "client",
    registeredDate: "2025-01-15",
    status: "active",
  },
  {
    id: 2,
    name: "Jane Smith",
    email: "jane.smith@example.com",
    role: "client",
    registeredDate: "2025-02-20",
    status: "active",
  },
  {
    id: 3,
    name: "Robert Johnson",
    email: "robert.j@example.com",
    role: "client",
    registeredDate: "2025-03-05",
    status: "inactive",
  },
  {
    id: 4,
    name: "Emily Davis",
    email: "emily.d@example.com",
    role: "client",
    registeredDate: "2025-03-10",
    status: "active",
  },
  {
    id: 5,
    name: "Michael Wilson",
    email: "michael.w@example.com",
    role: "admin",
    registeredDate: "2025-03-15",
    status: "active",
  },
]

export async function GET(request: Request, { params }: { params: { id: string } }) {
  const id = Number.parseInt(params.id)
  const user = users.find((u) => u.id === id)

  if (!user) {
    return NextResponse.json({ error: "User not found" }, { status: 404 })
  }

  return NextResponse.json(user)
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  const id = Number.parseInt(params.id)
  const updatedData = await request.json()

  const userIndex = users.findIndex((u) => u.id === id)

  if (userIndex === -1) {
    return NextResponse.json({ error: "User not found" }, { status: 404 })
  }

  // Update user data
  users[userIndex] = { ...users[userIndex], ...updatedData }

  return NextResponse.json(users[userIndex])
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  const id = Number.parseInt(params.id)

  const userIndex = users.findIndex((u) => u.id === id)

  if (userIndex === -1) {
    return NextResponse.json({ error: "User not found" }, { status: 404 })
  }

  // Remove user
  users = users.filter((u) => u.id !== id)

  return NextResponse.json({ success: true })
}
